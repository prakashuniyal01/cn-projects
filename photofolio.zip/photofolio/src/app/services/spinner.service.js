class SpinnerService {}

const spinnerService = new SpinnerService();

export default spinnerService;
