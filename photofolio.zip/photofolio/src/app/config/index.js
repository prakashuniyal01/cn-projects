import config from "./config";
import { db, auth } from "./db.config";

export { config, db, auth };
